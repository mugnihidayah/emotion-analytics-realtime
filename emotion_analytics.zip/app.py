# app.py
import streamlit as st
from streamlit_webrtc import webrtc_streamer, VideoProcessorBase, RTCConfiguration
import cv2
import av
import numpy as np
from logic import EmotionAnalyzer


# ==========================================================
#                   MODERN FULL-WIDTH UI CSS
# ==========================================================
st.markdown("""
<style>

/* Make page full width */
.main {
    max-width: 1600px;
    padding-left: 40px;
    padding-right: 40px;
    margin: 0 auto;
}

/* Tight top spacing */
.block-container {
    padding-top: 1rem;
}

/* Flex layout for dashboard */
.dashboard-row {
    display: flex;
    gap: 32px;
    width: 100%;
}

/* Column widths */
.left-col {
    flex: 3;
}
.right-col {
    flex: 1.5;
}

/* Card style */
.st-card {
    background: rgba(25, 26, 30, 0.85);
    border-radius: 22px;
    padding: 25px;
    box-shadow: 0 4px 22px rgba(0,0,0,0.3);
    backdrop-filter: blur(8px);
}

/* Typography */
.st-title {
    font-size: 2.7rem !important;
    font-weight: 700 !important;
    color: #ffffff !important;
    text-align: center;
}
.st-desc {
    text-align: center;
    color: #cfcfcf;
    font-size: 1.05rem;
}
.st-sub {
    font-size: 1.4rem;
    font-weight: 600;
    color: #ececec;
}
.st-info {
    color: #cacaca;
    font-size: 1rem;
}

hr {
    border: 0;
    border-top: 1px solid rgba(255,255,255,0.15);
    margin: 20px 0;
}

</style>
""", unsafe_allow_html=True)


# ==========================================================
#                 LOAD ANALYZER (CACHED)
# ==========================================================
@st.cache_resource
def load_analyzer():
    return EmotionAnalyzer()

analyzer = load_analyzer()


# ==========================================================
#                     PAGE HEADER
# ==========================================================
st.markdown("<h1 class='st-title'>🧠 Emotion Analytics Dashboard</h1>", unsafe_allow_html=True)
st.markdown("<p class='st-desc'>Real-time emotion analysis powered by YOLO + CNN + EMA smoothing</p>", unsafe_allow_html=True)
st.write("")


# ==========================================================
#       VIDEO PROCESSOR (NO FREEZE + NO FLICKER)
# ==========================================================
class EmotionProcessor(VideoProcessorBase):
    def __init__(self):
        self.frame_count = 0
        self.last_emotion = "Initializing..."
        self.last_score = 0

        self.bbox = None
        self.has_bbox = False

    def recv(self, frame):
        try:
            img = frame.to_ndarray(format="bgr24")
            img = cv2.flip(img, 1)
            self.frame_count += 1

            # ================= AI FRAME =================
            if self.frame_count % 5 == 0:
                processed, emo, score, new_bbox = analyzer.process_frame(img)

                self.last_emotion = emo
                self.last_score = score

                if new_bbox is not None:
                    new_bbox = np.array(new_bbox).astype(float)

                    if self.bbox is None:
                        self.bbox = new_bbox
                    else:
                        # EMA smoothing
                        self.bbox = 0.8 * self.bbox + 0.2 * new_bbox

                    self.has_bbox = True

                output = processed

            # ================= FAST FRAME =================
            else:
                output = img.copy()

            # ================= DRAW BBOX =================
            if self.has_bbox and self.bbox is not None:
                x1, y1, x2, y2 = self.bbox.astype(int)
                cv2.rectangle(output, (x1,y1), (x2,y2), (0,255,0), 2)

            # ================= DRAW OVERLAY PANEL =================
            panel = output.copy()
            cv2.rectangle(panel, (10,10), (360,110), (0,0,0), -1)
            output = cv2.addWeighted(panel, 0.45, output, 0.55, 0)

            cv2.putText(output, f"Emotion: {self.last_emotion}", (20,50),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.85, (255,255,255),2)

            cv2.putText(output, f"Engagement Score:", (20,80),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (230,230,230),1)

            bar_w = int((self.last_score/100)*300)
            cv2.rectangle(output, (20,90), (320,110), (255,255,255), 1)
            cv2.rectangle(output, (20,90), (20+bar_w,110), (0,255,0), -1)

            return av.VideoFrame.from_ndarray(output, format="bgr24")

        except Exception as e:
            print("ERROR in EmotionProcessor.recv:", e)
            return frame  # prevents freeze


# ==========================================================
#               DASHBOARD LAYOUT (FULL WIDTH)
# ==========================================================
st.markdown("<div class='dashboard-row'>", unsafe_allow_html=True)

# ---------------- LEFT COLUMN ----------------
st.markdown("<div class='left-col'>", unsafe_allow_html=True)
st.markdown("<div class='st-card'>", unsafe_allow_html=True)

st.markdown("<h3 class='st-sub'>🎥 Live Camera Feed</h3>", unsafe_allow_html=True)

webrtc_streamer(
    key="emotion-modern-ui",
    video_processor_factory=EmotionProcessor,
    rtc_configuration=RTCConfiguration(
        {"iceServers":[{"urls":["stun:stun.l.google.com:19302"]}]}
    ),
    media_stream_constraints={"video": True, "audio": False},
    async_processing=True
)

st.markdown("</div>", unsafe_allow_html=True)
st.markdown("</div>", unsafe_allow_html=True)


# ---------------- RIGHT COLUMN ----------------
st.markdown("<div class='right-col'>", unsafe_allow_html=True)
st.markdown("<div class='st-card'>", unsafe_allow_html=True)

st.markdown("<h3 class='st-sub'>📊 Analytics Insight</h3>", unsafe_allow_html=True)

st.markdown("""
<div class='st-info'>
Inferensi ekspresi wajah dengan stabilisasi EMA dan deteksi wajah YOLOv8.
<br><br>
<b>High Engagement:</b> Happy / Surprise<br>
<b>Medium Engagement:</b> Neutral<br>
<b>Low Engagement:</b> Sad / Angry / Fear
</div>
""", unsafe_allow_html=True)

st.markdown(f"<hr><div class='st-info'>Running on: <b>{analyzer.device}</b></div>", unsafe_allow_html=True)

st.markdown("</div>", unsafe_allow_html=True)
st.markdown("</div>", unsafe_allow_html=True)

# Close row
st.markdown("</div>", unsafe_allow_html=True)
